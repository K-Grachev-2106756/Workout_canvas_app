function openStopwatch(context){
    addAction({
        type: "open_stopwatch",
    }, context);
}

function startStopwatch(context){
    addAction({
        type: "start_stopwatch",
    }, context);
}

function stoppause(context){
    addAction({
        type: "stoppause",
    }, context);
}

function openCrossfit(context){
    addAction({
        type: "open_crossfit",
    }, context);
}

function startCrossfit(context){
    addAction({
        type: "start_crossfit",
    }, context);
}

function stopCrossfit(context){
    addAction({
        type: "stop_сrossfit",
    }, context);
}

function checkModeCrossfit(context){
    addAction({
        type: "check_mode_c",
    }, context);
}

function checkModeStopwatch(context){
    addAction({
        type: "check_mode_s",
    }, context);
}

function reset(context){
    addAction({
        type: "reset",
    }, context);
}

function checkCrossfit(context){
    addAction({
        type: "check_crossfit",
    }, context);
}

function checkStopwatch(context){
    addAction({
        type: "check_stopwatch",
    }, context);
}