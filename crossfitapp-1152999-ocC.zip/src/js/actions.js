function stoppause(context){
    addAction({
        type: "stoppause",
    }, context);
}

function checkModeCrossfit(context){
    addAction({
        type: "check_mode_c",
    }, context);
}

function checkModeStopwatch(context){
    addAction({
        type: "check_mode_s",
    }, context);
}

function reset(context){
    addAction({
        type: "reset",
    }, context);
}

function starting(context){
    addAction({
        type: "start",
    }, context);
}